/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercisiopilas;

/**
 *
 * @author aguti
 */
import java.util.Scanner;
public class Ejercisiopilas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        int []pila = new int[5];
        int tope = -1;
        int opcion;
        
        do {
            System.out.println("\n -- PILA CON ARREGLOS");
            System.out.println("1. AGREGAR UN NUMERO A LA PILA ");
            System.out.println("2. RETIRAR UN NUMERO DE LA PILA");
            System.out.println("3. MOSTRAR LA PILA");
            System.out.println("4. MOSTRAR EL TOPE");
            System.out.println("5. SALIR");
             System.out.println("6. OPCION");
             opcion=teclado.nextInt();
             
             switch(opcion){
               
                 case 1:
                     if (tope == pila.length-1){
                          System.out.println("HEY BROW LA PILA ESTA LLENA  ");
                     }else{
                        System.out.println("HEY BROW AGREGA UN ELEMENTO");
                        int numero = teclado.nextInt();
                        tope++;
                        pila[tope]=numero;
                     }
                     break;
                     
                 case 2 :
                     if (tope== -1){
                     System.out.println("HEY BROW LA PILA VACIA");
                     }else{
                     System.out.println("RETIRAR" + pila[tope]);
                     } break; 
                 
                 case 3 :
                      if (tope== -1){
                     System.out.println("HEY BROW LA PILA VACIA");
                     }else{
                     System.out.println("MOSTRAR LA PILA DE ELEMENTOS" + pila[tope]);
                     
                     for (int i = tope; i>=0 ; i--){
                       System.out.println("PILA" + pila[i]);   
                     }
                         
                     } break;
               
                 case 4 :
                       if (tope== -1){
                     System.out.println("HEY BROW LA PILA VACIA");
                     }else{
                     System.out.println("HEY BROW LA PILA VACIA" + pila[tope]);
                       }
                     break;
                    
                 case 5 :
                      System.out.println("FIN DEL PROGRAMA ");
                      break;
                 
                default:
                System.out.println("OPCION INVALIDA");
        }     
    }while(opcion !=5);
        
        teclado.close();
    
}
}
