/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pilsdnew;

/**
 *
 * @author aguti
 */
import java.util.Scanner;
import java.util.LinkedList;

public class Pilsdnew {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        LinkedList<String> pila = new LinkedList<>();

        int opcion;

        do {

            System.out.println("\n-- PILA CON LINKEDLIST --");
            System.out.println("1. AGREGAR UN ELEMENTO");
            System.out.println("2. RETIRAR UN ELEMENTO");
            System.out.println("3. MOSTRAR LA PILA");
            System.out.println("4. MOSTRAR EL TOPE");
            System.out.println("5. SALIR");
            System.out.print("OPCION: ");

            opcion = teclado.nextInt();

            switch (opcion) {

                case 1:
                    teclado.nextLine(); // limpiar buffer
                    System.out.print("Ingrese un elemento: ");
                    String palabras = teclado.nextLine();
                    pila.push(palabras);
                    break;

                case 2:
                    if (pila.isEmpty()) {
                        System.out.println("HEY BROW LA PILA ESTA VACIA");
                    } else {
                        System.out.println("RETIRADO: " + pila.pop());
                    }
                    break;

                case 3:
                    if (pila.isEmpty()) {
                        System.out.println("HEY BROW LA PILA ESTA VACIA");
                    } else {
                        System.out.println("ELEMENTOS DE LA PILA:");

                        for (String elemento : pila) {
                            System.out.println(elemento);
                        }
                    }
                    break;

                case 4:
                    if (pila.isEmpty()) {
                        System.out.println("HEY BROW LA PILA ESTA VACIA");
                    } else {
                        System.out.println("TOPE: " + pila.peek());
                    }
                    break;

                case 5:
                    System.out.println("FIN DEL PROGRAMA");
                    break;

                default:
                    System.out.println("OPCION INVALIDA");
                    break;
            }

        } while (opcion != 5);

        teclado.close();
    }
}